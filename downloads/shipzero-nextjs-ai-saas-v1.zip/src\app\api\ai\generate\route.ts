import { NextResponse } from "next/server";
import { z } from "zod";
import { generateCompletion } from "@/lib/ai-router";

const BodySchema = z.object({ prompt: z.string().min(3).max(4000) });

export async function POST(req: Request) {
  const parsed = BodySchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid prompt" }, { status: 400 });
  try {
    const output = await generateCompletion(parsed.data.prompt);
    return NextResponse.json({ ok: true, output });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "AI generation failed";
    return NextResponse.json({ error: msg }, { status: 502 });
  }
}
