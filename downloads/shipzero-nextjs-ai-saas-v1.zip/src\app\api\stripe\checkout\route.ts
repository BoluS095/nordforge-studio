import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { createProCheckoutSession } from "@/lib/stripe";

export async function POST() {
  const user = await getSession();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const session = await createProCheckoutSession(user.email, user.id);
  return NextResponse.json({ url: session.url });
}
