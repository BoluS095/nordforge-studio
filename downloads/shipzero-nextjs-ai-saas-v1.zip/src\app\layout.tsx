import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ShipZero — Launch Your AI Micro-SaaS in One Weekend",
  description: "Next.js 15 App Router, Stripe Checkout, JWT Auth, Multi-Provider AI Failover & Tailwind CSS.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-950 text-slate-100 antialiased">{children}</body>
    </html>
  );
}
