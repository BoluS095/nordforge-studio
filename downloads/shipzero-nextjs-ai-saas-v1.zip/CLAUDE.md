# ShipZero AI Micro-SaaS Architecture Guide (For Claude Code & Cursor)

## Stack & Conventions
- Next.js 15 App Router + TypeScript strict mode + Tailwind CSS
- Validate all API inputs with Zod before business logic
- Stripe webhooks must verify `stripe-signature` against raw request body
- Never expose server secrets in `NEXT_PUBLIC_*` variables
- All AI calls go through `src/lib/ai-router.ts` for automatic 429/503 failover
