# ShipZero — Production Next.js 15 AI Micro-SaaS Boilerplate

Launch your paid AI SaaS in 1 weekend without paying $249 for bloated starter kits.

## Included in Pro Package
- Next.js 15 App Router + TypeScript strict + Tailwind CSS
- Stripe Checkout & verified Webhook handler (`src/app/api/stripe/*`)
- HttpOnly JWT Session Auth (`src/lib/auth.ts`)
- Multi-Provider AI Router with 429/503 Failover (`src/lib/ai-router.ts`)
- Ready-to-use `CLAUDE.md` for Claude Code & Cursor vibe-coding
- MIT Commercial License (unlimited SaaS products & client projects)

## Quick Start
```bash
cp .env.example .env.local
npm install
npm run dev
```
