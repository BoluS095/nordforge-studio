export default function HomePage() {
  return (
    <main className="mx-auto max-w-4xl px-6 py-20 text-center">
      <span className="inline-block rounded-full bg-emerald-500/15 px-4 py-1 text-sm font-semibold text-emerald-300">
        Next.js 15 + Stripe + JWT Auth + Multi-LLM Failover
      </span>
      <h1 className="mt-6 text-5xl font-extrabold tracking-tight text-white">
        Ship Your AI Micro-SaaS Today — Not Next Quarter
      </h1>
      <p className="mx-auto mt-5 max-w-2xl text-lg text-slate-400">
        Zero bloated dependencies. Wired with Stripe Checkout &amp; Webhooks, HttpOnly JWT Auth, Zod API validation, and automatic OpenAI/Gemini/Anthropic failover.
      </p>
      <div className="mt-8 flex justify-center gap-4">
        <a href="/dashboard" className="rounded-xl bg-emerald-500 px-6 py-3 font-bold text-slate-950 hover:bg-emerald-400">
          Open SaaS Dashboard &rarr;
        </a>
      </div>
    </main>
  );
}
