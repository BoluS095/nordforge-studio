/**
 * Multi-Provider AI Router with Automatic 429/503 Failover (OpenAI -> Gemini -> Anthropic)
 */
export async function generateCompletion(prompt: string, systemPrompt = "You are a concise SaaS assistant.") {
  const providers: Array<() => Promise<string>> = [];

  if (process.env.OPENAI_API_KEY) {
    providers.push(async () => {
      const r = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [{ role: "system", content: systemPrompt }, { role: "user", content: prompt }],
        }),
      });
      if (!r.ok) throw new Error(`OpenAI ${r.status}`);
      const d = await r.json();
      return d.choices?.[0]?.message?.content || "";
    });
  }

  if (process.env.GEMINI_API_KEY) {
    providers.push(async () => {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${process.env.GEMINI_API_KEY}`;
      const r = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contents: [{ parts: [{ text: `${systemPrompt}\n\n${prompt}` }] }] }),
      });
      if (!r.ok) throw new Error(`Gemini ${r.status}`);
      const d = await r.json();
      return d.candidates?.[0]?.content?.parts?.[0]?.text || "";
    });
  }

  if (process.env.ANTHROPIC_API_KEY) {
    providers.push(async () => {
      const r = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": process.env.ANTHROPIC_API_KEY!,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: "claude-3-5-sonnet-latest",
          max_tokens: 1024,
          system: systemPrompt,
          messages: [{ role: "user", content: prompt }],
        }),
      });
      if (!r.ok) throw new Error(`Anthropic ${r.status}`);
      const d = await r.json();
      return d.content?.[0]?.text || "";
    });
  }

  let lastErr: unknown = new Error("No AI provider key configured in .env");
  for (const run of providers) {
    try {
      return await run();
    } catch (err) {
      lastErr = err;
    }
  }
  throw lastErr;
}
