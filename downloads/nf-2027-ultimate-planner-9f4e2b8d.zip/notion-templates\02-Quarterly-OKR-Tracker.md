# 2027 Quarterly OKRs

| Quarter | Objective | Key Result 1 | Key Result 2 | Status |
| :--- | :--- | :--- | :--- | :--- |
| Q1 | Reset Finances | Save $3,000 | Complete 30-Day No-Spend | In Progress |
| Q2 | Grow Income | +$1,000/mo Side Income | Invest 20% Auto | Planned |
| Q3 | Deep Focus | Ship Flagship Project | 90% Habit Streak | Planned |
| Q4 | Year-End Wealth | Debt Balance -50% | 2028 Roadmap | Planned |
