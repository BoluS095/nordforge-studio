# 2027 Weekly Habit & No-Spend Matrix

| Habit | Mon | Tue | Wed | Thu | Fri | Sat | Sun |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| 90m Deep Work | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| No Impulse Spend | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| Movement 30m | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
| Read 20 Pages | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |
