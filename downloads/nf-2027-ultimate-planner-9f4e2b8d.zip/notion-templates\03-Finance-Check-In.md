# Monthly Money Check-In (10-Minute Ritual)

1. Open `2027-Ultimate-Budget-NetWorth-Debt-Tracker.xlsx` (Excel or Google Sheets).
2. Log actual monthly income and category totals.
3. Verify 50/30/20 status on the Dashboard tab.
4. Transfer surplus directly into HYSA / Index ETF / smallest debt.
