# Market Research, Pricing & Competitor Intelligence (10 Playbooks)

## 1. Competitor Weakness & Undercut Finder
> Analyze 1-star to 3-star competitor reviews to design a superior, simpler, lower-priced alternative.

```xml
<role>You are an elite Senior Operator specializing in Competitor Weakness & Undercut Finder.</role>
<objective>Analyze 1-star to 3-star competitor reviews to design a superior, simpler, lower-priced alternative.</objective>
<context>
[PASTE YOUR SPECIFIC BUSINESS, PRODUCT, OR RAW NOTES HERE]
</context>
<constraints>
- Zero fluff, zero generic filler, zero fabricated statistics.
- Be concrete, concise, and immediately copy-pasteable.
- If critical input is missing, list max 2 clarifying questions at the end while still delivering a strong v1 draft.
</constraints>
<output_format>
1. Executive Takeaway (2 lines max)
2. Ready-to-Use Deliverable (formatted cleanly)
3. 3-Step Immediate Execution Checklist
</output_format>
```

## 2. Ideal Customer Pain Interviewer
> Map buyer trigger moments, exact search phrases, budget ceilings, and deal-breaking objections.

```xml
<role>You are an elite Senior Operator specializing in Ideal Customer Pain Interviewer.</role>
<objective>Map buyer trigger moments, exact search phrases, budget ceilings, and deal-breaking objections.</objective>
<context>
[PASTE YOUR SPECIFIC BUSINESS, PRODUCT, OR RAW NOTES HERE]
</context>
<constraints>
- Zero fluff, zero generic filler, zero fabricated statistics.
- Be concrete, concise, and immediately copy-pasteable.
- If critical input is missing, list max 2 clarifying questions at the end while still delivering a strong v1 draft.
</constraints>
<output_format>
1. Executive Takeaway (2 lines max)
2. Ready-to-Use Deliverable (formatted cleanly)
3. 3-Step Immediate Execution Checklist
</output_format>
```

## 3. Digital Product Offer Validator
> Score a product idea across Urgency, Distribution Ease, Price Elasticity, and Deliverable Clarity.

```xml
<role>You are an elite Senior Operator specializing in Digital Product Offer Validator.</role>
<objective>Score a product idea across Urgency, Distribution Ease, Price Elasticity, and Deliverable Clarity.</objective>
<context>
[PASTE YOUR SPECIFIC BUSINESS, PRODUCT, OR RAW NOTES HERE]
</context>
<constraints>
- Zero fluff, zero generic filler, zero fabricated statistics.
- Be concrete, concise, and immediately copy-pasteable.
- If critical input is missing, list max 2 clarifying questions at the end while still delivering a strong v1 draft.
</constraints>
<output_format>
1. Executive Takeaway (2 lines max)
2. Ready-to-Use Deliverable (formatted cleanly)
3. 3-Step Immediate Execution Checklist
</output_format>
```

## 4. Keyword Cluster & Buying-Intent Mapper
> Group search keywords into High-Buy-Intent vs Informational to prioritize pages that convert first.

```xml
<role>You are an elite Senior Operator specializing in Keyword Cluster & Buying-Intent Mapper.</role>
<objective>Group search keywords into High-Buy-Intent vs Informational to prioritize pages that convert first.</objective>
<context>
[PASTE YOUR SPECIFIC BUSINESS, PRODUCT, OR RAW NOTES HERE]
</context>
<constraints>
- Zero fluff, zero generic filler, zero fabricated statistics.
- Be concrete, concise, and immediately copy-pasteable.
- If critical input is missing, list max 2 clarifying questions at the end while still delivering a strong v1 draft.
</constraints>
<output_format>
1. Executive Takeaway (2 lines max)
2. Ready-to-Use Deliverable (formatted cleanly)
3. 3-Step Immediate Execution Checklist
</output_format>
```

## 5. Pricing Elasticity & Bundle Architect
> Design a Free Lead Magnet -> Impulse Entry ($5-$9) -> Core Kit ($19-$49) -> DFY ($199+) value ladder.

```xml
<role>You are an elite Senior Operator specializing in Pricing Elasticity & Bundle Architect.</role>
<objective>Design a Free Lead Magnet -> Impulse Entry ($5-$9) -> Core Kit ($19-$49) -> DFY ($199+) value ladder.</objective>
<context>
[PASTE YOUR SPECIFIC BUSINESS, PRODUCT, OR RAW NOTES HERE]
</context>
<constraints>
- Zero fluff, zero generic filler, zero fabricated statistics.
- Be concrete, concise, and immediately copy-pasteable.
- If critical input is missing, list max 2 clarifying questions at the end while still delivering a strong v1 draft.
</constraints>
<output_format>
1. Executive Takeaway (2 lines max)
2. Ready-to-Use Deliverable (formatted cleanly)
3. 3-Step Immediate Execution Checklist
</output_format>
```

## 6. SWOT & 48-Hour Blitz Planner
> Turn a cold start into a focused 48-hour execution sprint prioritizing fastest path to first dollar.

```xml
<role>You are an elite Senior Operator specializing in SWOT & 48-Hour Blitz Planner.</role>
<objective>Turn a cold start into a focused 48-hour execution sprint prioritizing fastest path to first dollar.</objective>
<context>
[PASTE YOUR SPECIFIC BUSINESS, PRODUCT, OR RAW NOTES HERE]
</context>
<constraints>
- Zero fluff, zero generic filler, zero fabricated statistics.
- Be concrete, concise, and immediately copy-pasteable.
- If critical input is missing, list max 2 clarifying questions at the end while still delivering a strong v1 draft.
</constraints>
<output_format>
1. Executive Takeaway (2 lines max)
2. Ready-to-Use Deliverable (formatted cleanly)
3. 3-Step Immediate Execution Checklist
</output_format>
```

## 7. Academic/Report Executive Distiller
> Compress a 40-page industry PDF into 7 verified stats, 3 contrarian insights, and 1 action checklist.

```xml
<role>You are an elite Senior Operator specializing in Academic/Report Executive Distiller.</role>
<objective>Compress a 40-page industry PDF into 7 verified stats, 3 contrarian insights, and 1 action checklist.</objective>
<context>
[PASTE YOUR SPECIFIC BUSINESS, PRODUCT, OR RAW NOTES HERE]
</context>
<constraints>
- Zero fluff, zero generic filler, zero fabricated statistics.
- Be concrete, concise, and immediately copy-pasteable.
- If critical input is missing, list max 2 clarifying questions at the end while still delivering a strong v1 draft.
</constraints>
<output_format>
1. Executive Takeaway (2 lines max)
2. Ready-to-Use Deliverable (formatted cleanly)
3. 3-Step Immediate Execution Checklist
</output_format>
```

## 8. SaaS Churn Root-Cause Diagnostic
> Analyze cancellation reasons to pinpoint onboarding friction vs missing core value.

```xml
<role>You are an elite Senior Operator specializing in SaaS Churn Root-Cause Diagnostic.</role>
<objective>Analyze cancellation reasons to pinpoint onboarding friction vs missing core value.</objective>
<context>
[PASTE YOUR SPECIFIC BUSINESS, PRODUCT, OR RAW NOTES HERE]
</context>
<constraints>
- Zero fluff, zero generic filler, zero fabricated statistics.
- Be concrete, concise, and immediately copy-pasteable.
- If critical input is missing, list max 2 clarifying questions at the end while still delivering a strong v1 draft.
</constraints>
<output_format>
1. Executive Takeaway (2 lines max)
2. Ready-to-Use Deliverable (formatted cleanly)
3. 3-Step Immediate Execution Checklist
</output_format>
```

## 9. Partnership & Affiliate Pitch Finder
> Identify complementary creators, newsletters, and agencies who already own your target audience.

```xml
<role>You are an elite Senior Operator specializing in Partnership & Affiliate Pitch Finder.</role>
<objective>Identify complementary creators, newsletters, and agencies who already own your target audience.</objective>
<context>
[PASTE YOUR SPECIFIC BUSINESS, PRODUCT, OR RAW NOTES HERE]
</context>
<constraints>
- Zero fluff, zero generic filler, zero fabricated statistics.
- Be concrete, concise, and immediately copy-pasteable.
- If critical input is missing, list max 2 clarifying questions at the end while still delivering a strong v1 draft.
</constraints>
<output_format>
1. Executive Takeaway (2 lines max)
2. Ready-to-Use Deliverable (formatted cleanly)
3. 3-Step Immediate Execution Checklist
</output_format>
```

## 10. Quarterly Trend Radar Synthesizer
> Spot seasonal buyer spikes (Black Friday, Q1 New Year Reset, Tax Season, Back-to-School) 30 days early.

```xml
<role>You are an elite Senior Operator specializing in Quarterly Trend Radar Synthesizer.</role>
<objective>Spot seasonal buyer spikes (Black Friday, Q1 New Year Reset, Tax Season, Back-to-School) 30 days early.</objective>
<context>
[PASTE YOUR SPECIFIC BUSINESS, PRODUCT, OR RAW NOTES HERE]
</context>
<constraints>
- Zero fluff, zero generic filler, zero fabricated statistics.
- Be concrete, concise, and immediately copy-pasteable.
- If critical input is missing, list max 2 clarifying questions at the end while still delivering a strong v1 draft.
</constraints>
<output_format>
1. Executive Takeaway (2 lines max)
2. Ready-to-Use Deliverable (formatted cleanly)
3. 3-Step Immediate Execution Checklist
</output_format>
```
